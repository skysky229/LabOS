make clean
make all
./logbuf