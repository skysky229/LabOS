make clean
make all
./dinPhil