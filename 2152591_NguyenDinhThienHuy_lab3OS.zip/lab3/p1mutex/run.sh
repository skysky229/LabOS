make clean
make all
./shrdmem