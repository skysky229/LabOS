make clean
make all
./main 20 4 4