make clean
make all
./pc 