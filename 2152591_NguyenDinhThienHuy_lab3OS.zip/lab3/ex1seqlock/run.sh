make clean
make all
./seqlock